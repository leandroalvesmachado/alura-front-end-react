import './styles/estilosGlobais.scss'
import PaginaInicial from "./paginas/PaginaInicial";

export default function App() {
  return <PaginaInicial/>;
}
